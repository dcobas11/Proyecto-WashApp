<a class="navbar-brand" href="index.php">
	<img src="media/washing-machine.png" class="d-inline-block align-top logo" alt="logo_wash_app">
	WashApp
</a>
<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
	<span class="navbar-toggler-icon"></span>
</button>