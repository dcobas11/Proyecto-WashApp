<?php

class Producto {
	public $id;
	public $nombre;
	public $precio;
	public $tipo;
}

?>